# Online Bookstore System

A cloud-based bookstore system built with Flask and SQLAlchemy.

## Features

- User authentication (login/register)
- Book catalog browsing
- Shopping cart functionality
- Order management
- Responsive design

## Installation

1. Clone the repository
2. Create a virtual environment:
   ```
   python -m venv venv
   venv\Scripts\activate
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Run the application:
   ```
   python app.py
   ```

## Usage

1. Register a new account or login with existing credentials
2. Browse the book catalog
3. Add books to your shopping cart
4. Complete the checkout process
5. View your order history

## Technologies Used

- Backend: Flask, SQLAlchemy
- Frontend: HTML, CSS, JavaScript
- Database: SQLite
- UI Framework: Bootstrap 5

## Project Structure

```
bookstore/
├── app.py              # Main application file
├── requirements.txt    # Project dependencies
├── static/            # Static files (CSS, JS)
│   ├── css/
│   └── js/
└── templates/         # HTML templates
    ├── base.html
    ├── home.html
    ├── login.html
    └── register.html
```
