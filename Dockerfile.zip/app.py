from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
import stripe
import os
from dotenv import load_dotenv
from flask_migrate import Migrate
from flask_caching import Cache
import boto3

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your-secret-key-here')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///bookstore.db')
app.config['STRIPE_PUBLIC_KEY'] = os.getenv('STRIPE_PUBLIC_KEY', 'your-stripe-public-key')
app.config['STRIPE_SECRET_KEY'] = os.getenv('STRIPE_SECRET_KEY', 'your-stripe-secret-key')

# AWS S3 Configuration
s3 = boto3.client('s3',
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
    region_name=os.getenv('AWS_REGION', 'us-east-1')
)
S3_BUCKET = os.getenv('S3_BUCKET')

# Redis Cache Configuration
cache = Cache(app, config={
    'CACHE_TYPE': 'redis',
    'CACHE_REDIS_URL': os.getenv('REDIS_URL', 'redis://localhost:6379/0')
})

stripe.api_key = app.config['STRIPE_SECRET_KEY']

db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    name = db.Column(db.String(100))
    is_admin = db.Column(db.Boolean, default=False)
    orders = db.relationship('Order', backref='user', lazy=True)
    cart_items = db.relationship('CartItem', backref='user', lazy=True)

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(50))
    image_url = db.Column(db.String(200))

class CartItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    book = db.relationship('Book')

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    date_ordered = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='pending')
    items = db.relationship('OrderItem', backref='order', lazy=True)
    payment_intent_id = db.Column(db.String(200))

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    book = db.relationship('Book')

# Admin Views
class AdminModelView(ModelView):
    def is_accessible(self):
        return current_user.is_authenticated and current_user.is_admin

admin = Admin(app, name='Bookstore Admin', template_mode='bootstrap3')
admin.add_view(AdminModelView(User, db.session))
admin.add_view(AdminModelView(Book, db.session))
admin.add_view(AdminModelView(Order, db.session))

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def home():
    category = request.args.get('category')
    search = request.args.get('search')
    sort = request.args.get('sort')
    
    query = Book.query
    
    if category:
        query = query.filter_by(category=category)
    if search:
        query = query.filter(Book.title.ilike(f'%{search}%') | Book.author.ilike(f'%{search}%'))
    if sort:
        if sort == 'price_asc':
            query = query.order_by(Book.price.asc())
        elif sort == 'price_desc':
            query = query.order_by(Book.price.desc())
    
    books = query.all()
    categories = db.session.query(Book.category).distinct()
    return render_template('home.html', books=books, categories=categories)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('home'))
        flash('Invalid email or password')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        name = request.form.get('name')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered')
            return redirect(url_for('register'))
        
        user = User(email=email,
                   password_hash=generate_password_hash(password),
                   name=name)
        db.session.add(user)
        db.session.commit()
        
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/cart')
@login_required
def cart():
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    total = sum(item.book.price * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)

@app.route('/add_to_cart/<int:book_id>', methods=['POST'])
@login_required
def add_to_cart(book_id):
    quantity = int(request.form.get('quantity', 1))
    cart_item = CartItem.query.filter_by(user_id=current_user.id, book_id=book_id).first()
    
    if cart_item:
        cart_item.quantity += quantity
    else:
        cart_item = CartItem(user_id=current_user.id, book_id=book_id, quantity=quantity)
        db.session.add(cart_item)
    
    db.session.commit()
    return redirect(url_for('cart'))

@app.route('/remove_from_cart/<int:item_id>')
@login_required
def remove_from_cart(item_id):
    cart_item = CartItem.query.get_or_404(item_id)
    if cart_item.user_id == current_user.id:
        db.session.delete(cart_item)
        db.session.commit()
    return redirect(url_for('cart'))

@app.route('/create-payment-intent', methods=['POST'])
@login_required
def create_payment_intent():
    try:
        print("Creating payment intent...")  # Debug log
        cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
        if not cart_items:
            print("Cart is empty")  # Debug log
            return jsonify({"error": "Your cart is empty"}), 400

        total_amount = sum(item.book.price * item.quantity for item in cart_items)
        print(f"Total amount: ${total_amount}")  # Debug log
        
        # Create a PaymentIntent with the order amount and currency
        intent = stripe.PaymentIntent.create(
            amount=int(total_amount * 100),  # Convert to cents
            currency='usd',
            metadata={
                'user_id': current_user.id,
                'user_email': current_user.email
            }
        )
        print(f"Payment intent created: {intent.id}")  # Debug log
        
        return jsonify({
            'clientSecret': intent.client_secret,
            'amount': total_amount
        })
    except stripe.error.StripeError as e:
        print(f"Stripe error: {str(e)}")  # Debug log
        return jsonify({"error": str(e)}), 403
    except Exception as e:
        print(f"Unexpected error: {str(e)}")  # Debug log
        return jsonify({"error": "An unexpected error occurred"}), 500

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    if request.method == 'POST':
        try:
            print("Processing checkout...")  # Debug log
            payment_intent_id = request.form.get('payment_intent_id')
            print(f"Payment intent ID: {payment_intent_id}")  # Debug log
            
            if not payment_intent_id:
                print("No payment intent ID provided")  # Debug log
                flash('Payment information is missing.', 'error')
                return redirect(url_for('checkout'))

            # Verify the payment intent
            payment_intent = stripe.PaymentIntent.retrieve(payment_intent_id)
            print(f"Payment intent status: {payment_intent.status}")  # Debug log
            
            if payment_intent.status != 'succeeded':
                print(f"Payment not successful: {payment_intent.status}")  # Debug log
                flash('Payment was not successful.', 'error')
                return redirect(url_for('checkout'))

            cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
            total_amount = sum(item.book.price * item.quantity for item in cart_items)
            print(f"Creating order for ${total_amount}")  # Debug log

            # Create the order
            order = Order(
                user_id=current_user.id,
                total_amount=total_amount,
                payment_intent_id=payment_intent_id,
                status='completed'
            )
            db.session.add(order)
            db.session.flush()  # Get the order ID
            print(f"Order created with ID: {order.id}")  # Debug log

            # Create order items and update stock
            for cart_item in cart_items:
                order_item = OrderItem(
                    order_id=order.id,
                    book_id=cart_item.book_id,
                    quantity=cart_item.quantity,
                    price=cart_item.book.price
                )
                db.session.add(order_item)
                print(f"Added order item: {cart_item.book.title} x {cart_item.quantity}")  # Debug log

                # Update book stock
                book = cart_item.book
                if book.stock < cart_item.quantity:
                    print(f"Insufficient stock for {book.title}")  # Debug log
                    flash(f'Not enough stock for {book.title}', 'error')
                    return redirect(url_for('cart'))
                book.stock -= cart_item.quantity

                # Remove cart item
                db.session.delete(cart_item)

            db.session.commit()
            print("Order completed successfully")  # Debug log
            flash('Order placed successfully!', 'success')
            return redirect(url_for('orders'))

        except stripe.error.StripeError as e:
            print(f"Stripe error during checkout: {str(e)}")  # Debug log
            flash(f'Payment error: {str(e)}', 'error')
            return redirect(url_for('checkout'))
        except Exception as e:
            print(f"Unexpected error during checkout: {str(e)}")  # Debug log
            flash('An unexpected error occurred', 'error')
            return redirect(url_for('checkout'))

    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    total = sum(item.book.price * item.quantity for item in cart_items)
    
    # Pass Stripe public key to template
    stripe_public_key = app.config['STRIPE_PUBLIC_KEY']
    print(f"Rendering checkout page with total: ${total}")  # Debug log
    return render_template('checkout.html', 
                         cart_items=cart_items, 
                         total=total, 
                         stripe_public_key=stripe_public_key)

@app.route('/orders')
@login_required
def orders():
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.date_ordered.desc()).all()
    return render_template('orders.html', orders=orders)

def init_db():
    with app.app_context():
        # Drop all tables
        db.drop_all()
        # Create all tables
        db.create_all()
        
        # Create admin user
        admin = User(
            email='admin@example.com',
            name='Admin',
            is_admin=True,
            password_hash=generate_password_hash('admin123')
        )
        db.session.add(admin)
        
        # Add some sample books
        sample_books = [
            {
                'title': 'The Great Gatsby',
                'author': 'F. Scott Fitzgerald',
                'price': 9.99,
                'stock': 50,
                'description': 'A story of decadence and excess.',
                'category': 'Fiction',
                'image_url': 'https://m.media-amazon.com/images/I/71FTb9X6wsL._AC_UF1000,1000_QL80_.jpg'
            },
            {
                'title': 'To Kill a Mockingbird',
                'author': 'Harper Lee',
                'price': 12.99,
                'stock': 30,
                'description': 'A classic of modern American literature.',
                'category': 'Fiction',
                'image_url': 'https://m.media-amazon.com/images/I/71FxgtFKcQL._AC_UF1000,1000_QL80_.jpg'
            },
            {
                'title': 'Python Programming',
                'author': 'John Smith',
                'price': 29.99,
                'stock': 25,
                'description': 'A comprehensive guide to Python.',
                'category': 'Programming',
                'image_url': 'https://m.media-amazon.com/images/I/71PmGUNShOL._AC_UF1000,1000_QL80_.jpg'
            }
        ]
        
        for book_data in sample_books:
            book = Book(**book_data)
            db.session.add(book)
        
        db.session.commit()
        print("Database initialized with admin user and sample books!")

if __name__ == '__main__':
    init_db()  # Initialize the database with sample data
    app.run(debug=True)
