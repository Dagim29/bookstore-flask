from app import app, db, User
from werkzeug.security import generate_password_hash
import os

def setup():
    with app.app_context():
        # Remove existing database if it exists
        if os.path.exists('bookstore.db'):
            os.remove('bookstore.db')
        
        # Create all tables
        db.create_all()
        
        # Create admin user
        admin = User(
            email='admin@example.com',
            name='Admin',
            is_admin=True,
            password_hash=generate_password_hash('admin123')
        )
        db.session.add(admin)
        db.session.commit()
        print("Database initialized and admin user created successfully!")

if __name__ == '__main__':
    setup()
